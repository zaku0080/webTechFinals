<?php
include('config.php');


$stmt = $conn->query("UPDATE http_ident SET u_answer = '' ");

if($stmt){
    session_destroy();
    header('location:Index.html');
}

?>