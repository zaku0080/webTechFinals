<?php
    include('config.php');
    $random = $_SESSION['random'];

    if(!empty($_POST['answer'])){
        $u_answer = $conn->real_escape_string($_POST['answer']);

        echo $u_answer;
        $set = $conn->query("UPDATE http_ident SET u_answer = UPPER('$u_answer') WHERE no = '$random' ");
       
        if($set){
            header('location:http_ident.php');
        } else {
            echo "Hindi siya na save";
        }
    }else{
            header('location:http_ident.php');
    }
?>
