<?php
    include('config.php');

    $stmt = $conn->query("SELECT * FROM `http_ident` WHERE `u_answer`!= ''");
    $res = mysqli_num_rows($stmt);
?>

<!DOCTYPE html>

<html>
    <head>
        <title>Review Answers</title>
        <link rel="stylesheet" href="quiz.css">
    </head>
    
    <body>
        <table>
            <thead>
            <th>Question</th>
            <th> Your Answer </th>
</thead>
<?php 
    if($res > 0){
        while($row = mysqli_fetch_array($stmt)){
            

    ?>
        <tr> 
            <td><?php echo $row['question'];?> </td>
            <td> <?php echo $row['u_answer'];?> </td>
            <td> 
    </td>
        </tr> 
<?php
            
        }
    }
    ?>    
        </table>
        <br>
        <br>

        <a href="score_http.php"><button id="Score">Submit Quiz</button></a>
        <a href="http_ident.php"><button id="Score">Back</button></a>
</body>
</html>    
