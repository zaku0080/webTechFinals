<?php
    include('config.php');
    $score = 0;

    $stmt = $conn->query("SELECT * FROM `css_ident` WHERE `u_answer`!= ''");
    $res = mysqli_num_rows($stmt);
    
   if($res > 0){
        while($row = mysqli_fetch_array($stmt)){
            if($row['answer'] == $row['u_answer']){
                $score++;
            }
        }
    }
?>
<!DOCTYPE html>

<html>
	<head>
		<title>Score</title>
		<link rel="stylesheet" href="quiz.css">
	</head>
	<style>
		div {
		  background-color: white;
		  width: 30px;
		  height: 15px;
		  border: 5px solid black;
		  padding: 7%;
		  margin-left: 41%;
		  margin-right: 50%;
		  margin-bottom: 5%;
		  text-align:center;
		  
		}
	</style>
	
	<body>
		<div>
			<p> Your Score: <?php echo $score;?> / <?php echo $_SESSION['q_num']; ?>
		</div>
	
	<a href="reviewResult_css.php"><button id="End">Review result</button></a><br>
	<a href="end_css.php"><button id="End">END</button></a>
	</body>
</html>