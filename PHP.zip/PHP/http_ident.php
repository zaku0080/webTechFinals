<?php
    include('config.php');

		$q_number = $_SESSION['q_num']; // gagamitin yung value para sa pag gawa ng counter... 
		
		
			$random = mt_rand(1,50); //pipiliin ng number from 1 to 50 tapos gagamitin sa query for random questions...
			$_SESSION['random'] = $random;

    //gagawa ng counter para sa number of questions na sasagutan ng user. for loop? or for each? ewan ko
    /**
		 * 
		 */
		
	$stmt = $conn->query("SELECT no, question FROM http_ident WHERE no = '$random'");
	if($stmt){
		$row = mysqli_fetch_array($stmt);
	}
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Quiz</title>
		<link rel="stylesheet" href="quiz.css">
	</head>
	<style>
		div {
		  background-color: white;
		  width: 1125px;
		  border: 5px solid black;
		  padding: 7%;
		  margin-top: 5px;
		  margin: 5px;
		  margin-bottom: 10px;
		}
	</style>
	<body>
		<div>
			<form method="POST" action="save_http.php">
                <p> <?php echo $row['question']; // dito magegenerate yung mga questions galing sa database...
                ?> 
				<br>
					<input type="text" name="answer" >
		</div>
	
		<button id="previous">&laquo; Previous</button>
			<input type= 'submit' value = "Next &raquo;" id="next"> 
			</form>
			
	<br>
	<br>
	<a href="reviewAnswers_http.php"><button id="ReviewAnswers">Review Answers</button></a>
	<a href="score_http.php"><button id="Score">Submit Quiz</button></a>
	
	
	</body>
</html>