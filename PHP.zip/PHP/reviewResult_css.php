<?php
    include('config.php');

    $stmt = $conn->query("SELECT * FROM `css_ident` WHERE `u_answer`!= ''");
    $res = mysqli_num_rows($stmt);
?>
<!DOCTYPE html>

<html>
	<head>
		<title>Review Answers</title>
		<link rel="stylesheet" href="quiz.css">
	</head>
	
	<body>
        <table>
            <thead>
            <th> Question</th>
            <th> Your Answer </th>
            <th> Correct Answer </th>
            <th> Remarks </th>
</thead>
<?php 
    if($res > 0){
        while($row = mysqli_fetch_array($stmt)){
            

    ?>
        <tr> 
            <td><?php echo $row['question'];?> </td>
            <td> <?php echo $row['u_answer'];?> </td>
            <td> <?php echo $row['answer'];?> </td>
            <td> 
            <?php if($row['answer'] == $row['u_answer']){
                echo "CORRECT";
            }else{
                echo "WRONG";
            }
            ?> </td>
        </tr> 
<?php
            
        }
    }
    ?>    
        </table>
        <br>
        <br>
        <a href="end_css.php"><button id="End">END</button></a>
    </body>

</html>