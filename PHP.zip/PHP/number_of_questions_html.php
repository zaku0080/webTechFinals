<?php
session_start();

if(isset($_POST['q_num'])){
    $_SESSION['q_num'] = $_POST['q_num'];
    header('location:html_ident.php');
}


?>
