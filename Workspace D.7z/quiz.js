const http = require('http');
//const fs = require('fs');

http.createServer(function(require,response){
	
function navButton() {
	document.getElementById('q-con').textContent = 'This text is different!';
}
	

	response.end();
}).listen(8081);
