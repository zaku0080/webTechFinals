
QuizCreator Template Installation Guide

1.Download the quiz template file （.thm file).
2.Save the .thm files in QuizData folder under the installation directory of Wondershare QuizCreator.
For example: C:\Program Files\Wondershare\QuizCreator\QuizData\Themes\Theme Custom 
